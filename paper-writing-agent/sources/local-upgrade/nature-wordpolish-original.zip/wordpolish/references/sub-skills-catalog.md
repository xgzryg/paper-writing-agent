﻿---
name: wordpolish-sub-skills-catalog
description: |
  wordpolish 调度的 15 个 sub-skill 详细说明。
  每个 sub-skill 含：来源、适用、触发词、已知限制、与同类的差异。
---

# wordpolish 调度的 15 个 sub-skill 详细目录

> 直白说明：本目录是 wordpolish 路由决策时的参考资料。

## A. 中文通用去 AI 味（3 个）

### A1. humanizer-zh
- **来源**：op7418/Humanizer-zh（15004 ⭐）
- **路径**：`skills/humanizer-zh/SKILL.md`
- **定位**：维基百科 "Signs of AI writing" 项目背书的 9 模式识别
- **9 模式**：夸大象征意义 / 宣传性语言 / -ing 结尾的肤浅分析 / 模糊归因 / 破折号过度使用 / 三段式法则 / AI 词汇 / 否定式排比 / 连接性短语堆砌
- **限制**：单文件 SKILL.md（19 KB），无 references/

### A2. unclecheng-reduce-ai-perception-v2__skillhub
- **来源**：unclecheng（同名 GitHub 仓库，疑似 SkillHub 收录）
- **路径**：`skills/unclecheng-reduce-ai-perception-v2__skillhub/SKILL.md`
- **定位**：8 类问题检测（比 humanizer-zh 更全）
- **8 类**：AI 高频词汇 / 过度结构化 / 虚假客观性 / 机械化连接词 / 完美主义陷阱 / 公式化结尾 / 过度修饰 / 情感缺失
- **与 humanizer-zh 差异**：unclecheng 多了"完美主义陷阱"和"虚假客观性"两个检测维度；humanizer-zh 多了"破折号过度"和"否定式排比"
- **建议链式**：humanizer-zh（检测）→ unclecheng（精修） 或反之

### A3. ai-flavor-remover（Codex 模式改造版）
- **来源**：hylarucoder/ai-flavor-remover（重写为 Codex 模式）
- **路径**：`skills/ai-flavor-remover/SKILL.md`
- **定位**：操作清单型通用改写
- **8 条 Guidelines**：句式灵动 / 词汇鲜活 / 自然过渡 / 视角与情感 / 互动感营造 / 节奏把控 / 避免 AI 习语 / 口语化与书面语平衡
- **5 步工作流**：需求理解 → 原文诊断 → 分步精修 → 一致性检查 → 通读微调
- **与 A1/A2 差异**：humanizer-zh / unclecheng 是"模式识别型"，ai-flavor-remover 是"操作清单型"
- **建议链式**：A1 → A3 或 A2 → A3（检测 → 精修）

## B. 中文场景化改写（4 个）

### B1. shuorenhua
- **来源**：MrGeDiao/shuorenhua（v2.2.1）
- **路径**：`skills/shuorenhua/SKILL.md`
- **定位**：场景化中文改写（小红书 / 公众号 / 工程师笔记）
- **核心立场**："先保信息，再谈风格"
- **生态**：含 `.claude-plugin/` + 16 版本 eval 体系 + 多平台 install 指引
- **限制**：完全维护中，v2.2.1 是当前最新

### B2. content-rewriter
- **来源**：Codex 内置 skill
- **路径**：`skills/content-rewriter/SKILL.md`
- **定位**：跨平台中文社交媒体改写（小红书 / 微博 / 公众号等）
- **特点**：针对平台调 tone / format / length / style
- **与 B1 差异**：B1 强保信息，B2 强跨平台适配

### B3. wechat-mp-suite__skillhub
- **来源**：SkillHub 收录（"微信公众号终极工作台"）
- **路径**：`skills/wechat-mp-suite__skillhub/SKILL.md`
- **定位**：公众号端到端工作台
- **8 模块**：搜索 / 爬虫 / 写作（刘润风格/爆款推文/真人写作）/ 洗稿 / AI 配图 / 专业排版 / 发布（本地/远程 MCP）
- **依赖**：node / python3 / curl / jq
- **使用场景**：要发公众号时一站式

### B4. copywriting
- **来源**：Codex 内置 skill
- **路径**：`skills/copywriting/SKILL.md`
- **定位**：营销文案（homepage / landing / pricing / feature / about / product page）
- **特点**：偏向商业转化文案，不是 social media 内容

## C. 学术（中/英）（4 个）

### C1. humanizer-zh-academic
- **来源**：redbaronyyyyy-eng/humanizer-zh-academic
- **路径**：`skills/humanizer-zh-academic/SKILL.md`
- **定位**：中文学术写作降 AIGC
- **实测数据**：AIGC 率从 >50% → 11%
- **11 种学术 AI 模式**：理论依据式起笔 / "此案例印证了" 套路结尾 / 整齐并列句 / 模板化问题陈述 / 被动分析套话 / 过度对称结构 / 画蛇添足总结句 / 模糊归因 / 填充短语 / 通用积极结论 / AI 高频词滥用
- **触发词**：降低 AI 率 / 人工润色 / 降低 AIGC / humanize / 去 AI 味 / 论文降重

### C2. chinese-thesis-workbench
- **来源**：Codex 内置 skill
- **路径**：`skills/chinese-thesis-workbench/SKILL.md`
- **定位**：中文本科毕业论文 / 毕业设计论文工作台
- **AIGC 治理**：含 `scripts/review/analyze_aigc_style.py`（Python 脚本）+ `references/writing/aigc-style-governance.md`
- **核心规则**："AIGC style changes do not add facts"
- **治理流程**：standards → evidence → reference → figure → DOCX → AIGC checks（6 个 quality gates）
- **与 C1 差异**：C1 是模式识别型，C2 是工程化治理（含脚本批处理）

### C3. nature-polishing
- **来源**：Codex 内置 skill
- **路径**：`skills/nature-polishing/SKILL.md`
- **定位**：Nature 期刊学术英文润色
- **支持**：Academic Phrasebank + Nature/Nature Communications article patterns + writing-strategy principles
- **触发**：用户提到 "polish manuscript"、"Nature 风格"、"academic prose"
- **使用语言**：英文

### C4. de-ai-writing
- **来源**：OUBIGFA/De-AI-Prompt-Enhancer-Writer-Booster-SKILL/de-AI-writing
- **路径**：`skills/de-AI-writing/SKILL.md`
- **定位**：保真改写 + 反模板硬约束
- **硬约束**：禁用"而是"变体 / 禁用协作路标词 / 控制冒号和二人称
- **5 种任务**：从零生成 / 改写 / 翻译（结构保真） / 审阅 / 精修
- **与 C1 差异**：C1 重检测，C4 重"保结构 + 改写"

## D. 风格化（1 个）

### D1. good-writing
- **来源**：OUBIGFA/De-AI-Prompt-Enhancer-Writer-Booster-SKILL/good-writing
- **路径**：`skills/good-writing/SKILL.md`
- **定位**：作家风格复现（中文）
- **DNA 来源**：7 篇真实作者文章
- **特点**：半文半白用词 / 长短交替句式 / 类比先行 / 冷面热心
- **配套**：`.writer/` 目录（7 篇范文） + `references/style-summary.md`

## E. 英文去 AI 味（2 个）— v2 新增

### E1. writer
- **来源**：Codex 内置 skill
- **路径**：`skills/writer/SKILL.md`
- **定位**：英文修 AI 写作模式
- **核心**："Fix AI writing patterns that create repetitive and robotic content"
- **使用语言**：英文

### E2. rupert-content-rewriter
- **来源**：Codex 内置 skill
- **路径**：`skills/rupert-content-rewriter/SKILL.md`
- **定位**：英文跨平台改写（Twitter / LinkedIn / Blog）
- **能力**：调 tone（professional/casual/funny/formal） / 翻译 / 摘要 / 扩展 / SEO
- **使用语言**：英文

## F. 辅助（1 个）

### F1. slides-polish
- **来源**：Codex 内置 skill
- **路径**：`skills/slides-polish/SKILL.md`
- **定位**：学术 slide 润色（per-page review + python-pptx/Beamer fixes）
- **使用场景**：生成的 PPTX/Beamer "看起来差不多"但用户要最后一轮精修

## 选型决策提示

| 用户说 | 优先 sub-skill | 备选 |
|---|---|---|
| "去 AI 味"（无场景） | A1 humanizer-zh | A2 unclecheng |
| "帮我看看这篇小红书" | B1 shuorenhua | B2 content-rewriter |
| "论文降 AIGC" | C1 humanizer-zh-academic | C2 chinese-thesis-workbench |
| "帮我发公众号" | B3 wechat-mp-suite | B1 shuorenhua |
| "改英文" | E1 writer | E2 rupert-content-rewriter |
| "Nature 投稿润色" | C3 nature-polishing | E1 writer |
| "模仿 XX 风格" | D1 good-writing | — |
| "保真翻译" | C4 de-ai-writing | — |
| "slide 终稿" | F1 slides-polish | — |
