﻿---
name: wordpolish-routing-table
description: |
  wordpolish 路由决策表（v2）。15 个 sub-skill 的触发关键词、特征、调用方式。
---

# wordpolish 路由决策表（v2）

> 直白说明：本表是 wordpolish agent 选择 sub-skill 的依据。
> 输入：场景信号（含用户原话关键词 + 自动识别的文本特征）
> 输出：调用的 sub-skill 列表（可能多个链式）

## 触发关键词 → sub-skill 映射

### A. 中文通用去 AI 味（3 个）

#### A1. humanizer-zh（兜底默认）
**优先级**：兜底默认。
**触发关键词**：通用词（改写 / 润色 / 去 AI 味 / 改一下 / 调整 / 优化一下）/ 文本类型（日记 / 朋友圈 / 一般邮件 / 日常写作）/ 场景信号【未指定场景】
**特征**：没有明确场景标签，没有学术/小红书/技术文档特征
**调用方式**：单 skill。可与 A2/A3 链式。

#### A2. unclecheng-reduce-ai-perception-v2__skillhub（8 类问题检测）
**触发关键词**：8 类问题检测（AI 高频词 / 过度结构化 / 虚假客观性 / 机械化连接词 / 完美主义陷阱 / 公式化结尾 / 过度修饰 / 情感缺失）
**特征**：用户说"全方位改"、"全面去 AI 味"、"逐项检测"
**与 A1 差异**：A2 检测范围更广（含虚假客观性 / 完美主义陷阱），A1 检测更细（含破折号 / 否定式排比）
**调用方式**：单 skill。可与 A1 链式（A1 先粗检，A2 细查）。

#### A3. ai-flavor-remover（操作清单型）
**触发关键词**：按步骤改 / 按指引改 / 按清单改 / Humanization Guidelines / 原文是按 Gemini prompt 写的
**特征**：用户要"按操作清单"执行；或链式第二步精修
**与 A1/A2 差异**：A1/A2 是模式识别型，A3 是操作清单型
**调用方式**：单 skill 或链式第二步。

### B. 中文场景化改写（4 个）

#### B1. shuorenhua（小红书/公众号/工程师笔记）
**触发关键词**：小红书 / 公众号 / 朋友圈 / 知乎 / 微博 / 短视频脚本 / 说人话 / 别太像模板 / 别像 ChatGPT / 自然一点 / 工程师笔记 / 复盘 / 事故复盘 / PRD / 发布说明
**特征**：场景明确指向内容创作平台或工作场景；用户要求保留信息优先
**调用方式**：单 skill。可与 A1 链式（A1 → B1）。

#### B2. content-rewriter（跨平台中文社交媒体）
**触发关键词**：跨平台 / 一稿多用 / 适配微博知乎小红书
**特征**：同一内容要发多个平台
**与 B1 差异**：B1 强保信息，B2 强跨平台适配
**调用方式**：单 skill。

#### B3. wechat-mp-suite__skillhub（公众号端到端）
**触发关键词**：发公众号 / 公众号全流程 / 写公众号推文 / 洗稿 / 公众号排版 / 公众号 AI 配图
**特征**：用户要"发公众号"而不是只"改一篇文章"
**依赖**：node / python3 / curl / jq（必须）
**调用方式**：单 skill（含发布动作）。

#### B4. copywriting（营销文案）
**触发关键词**：landing page / pricing page / feature page / about page / product page / 营销文案 / 转化文案 / 销售页
**特征**：商业转化文案，不是 social media 内容
**调用方式**：单 skill。

### C. 学术（中/英）（4 个）

#### C1. humanizer-zh-academic（中文学术降 AIGC）
**触发关键词**：论文 / 期刊 / 毕业论文 / 投稿 / 学位论文 / 降 AI 率 / 降 AIGC / 学术 / 学术写作 / 研究报告 / 实验报告 / AI 痕迹消除 / 人工润色 / 论文降重 / humanize（学术语境）
**特征**：文本是学术写作（论文化句式、引用、研究方法描述）
**调用方式**：单 skill。可与 B1 链式（C1 → B1）。

#### C2. chinese-thesis-workbench（中文论文 AIGC 工程化治理）
**触发关键词**：本科毕业论文 / 毕设 / 毕业论文 / 论文工程化 / 论文批处理 / AIGC 工程化治理
**特征**：用户要批量治理 AIGC，不是单篇改写
**与 C1 差异**：C1 是单篇模式识别，C2 是工程化批处理（含 Python 脚本）
**调用方式**：单 skill（独立流程）。

#### C3. nature-polishing（Nature 期刊英文润色）
**触发关键词**：Nature 投稿 / Nature Communications / 期刊润色 / polish manuscript / academic prose / Nature-leaning English
**特征**：英文 + 学术 + Nature 级别
**调用方式**：单 skill。

#### C4. de-ai-writing（保真改写 + 反模板）
**触发关键词**：翻译 / 结构保真 / 审阅 / 找问题 / 评分 / 保留原意 / 保留风格 / 不要改结构 / 终稿精修 / 局部微调 / 别大改
**特征**：翻译任务（中英互译保结构）/ 审阅任务（不改只标问题）/ 轻度微调
**调用方式**：单 skill。可作为链式第二步（如 A1 → C4 精修）。

### D. 风格化（1 个）

#### D1. good-writing（作家风格复现）
**触发关键词**：模仿 / 仿写 / 学某人风格 / 像 XX 写 / 作家风格 / 我的文风 / 复现风格 / 风格档案 / 风格 DNA / 7 篇文章 / 样本 / 我之前写的
**特征**：用户提供了参考文章或作者；要求"按自己风格写"
**限制**：不参与链式（已经是"风格化" skill，再链磨平）
**调用方式**：单 skill。

### E. 英文去 AI 味（2 个）— v2 新增

#### E1. writer（英文修 AI 写作模式）
**触发关键词**：英文 / English / 英文 AI 写作模式 / repetitive content / robotic content / English de-AI
**特征**：用户输入是英文 + 要去 AI 味
**调用方式**：单 skill。可与 E2 或 C3 链式。

#### E2. rupert-content-rewriter（英文跨平台）
**触发关键词**：Twitter / LinkedIn / Blog（英文）/ SEO 优化 / professional tone / casual tone
**特征**：英文 + 跨平台
**调用方式**：单 skill。

### F. 辅助（1 个）

#### F1. slides-polish（学术 slide 润色）
**触发关键词**：PPT / slide / Beamer / 幻灯片 / 终稿精修
**特征**：文本是 slide 内容（短句 + 标题），不是文章
**调用方式**：单 skill。

## 冲突解决

| 冲突情况 | 处理 |
|---|---|
| 多个 sub-skill 都触发 | 按"用户原文最近一次提到的关键词"优先 |
| 用户说"加强"或"极致" | 触发链式（按 chain-rules.md，数量按需）|
| 文本本身场景模糊 | A1 humanizer-zh 兜底 |
| 中英文混合 | 优先按用户主要语言选择；链式可跨语言 |
| 用户没指定模型但用 ai-flavor-remover 关键词 | 提示"已重写为 Codex 模式"，可直接调用 |

## 不要做的路由

- ❌ 不路由到 writing-agent（用户明确排除）
- ❌ 不路由到任何 sub-skill 处理代码、命令、报错
- ❌ 不路由到 sub-skill 处理纯翻译任务（除非用户说"翻译并改写"）
- ❌ 不要用 D1 good-writing 进入链式（已经是风格化，再链磨平作者性）
