---
name: journal-if-lookup
description: Look up academic journals in the local JCR 2025 index (22,643 records).
  Accepts full names, JCR abbreviations, ISSNs, or fragments. Returns the 2025 JIF,
  5-year JIF, JIF quartile/rank, JCI, AIS, publisher, ISSN, citations, eigenfactor,
  and per-category quartiles. NEVER fabricates a journal — if the input is ambiguous,
  returns a candidates list and asks the user to confirm. If the input has no good
  match, returns the closest real titles for the user to pick from.
visibility: public
display_name: journal-if-lookup
display_name_en: journal-if-lookup
agent_created: true
disable: false
---

# Journal IF Lookup

A local, offline-capable lookup against the JCR 2025 release (Clarivate
Journal Citation Reports). The user provides a journal name, abbreviation,
or ISSN — the skill returns the full JIF record.

## When To Use

- "查询 Lancet 的影响因子"
- "JAMA 2025 JIF 是多少？"
- "1471-0072 是什么期刊？"
- "Nature Reviews Molecular Cell Biology 在哪个区？"
- "帮我看下 plso 这个缩写是哪个刊？" *(typo, abbreviation variant)*
- "jmam" *(typo — candidate list includes JAMA family)*

## When NOT To Use

- 中科院分区 (CAS tier list) — not in this dataset. Suggest the user check
  the latest LetPub / 中科院文献情报中心 release separately.
- 实时引用数 / 引用了某文的论文 — needs CrossRef / Web of Science API.
- 期刊投稿指南、审稿周期 — needs publisher website.
- 期刊历史变更 / 更名 — needs Ulrich's or publisher records.

## Iron Rule: No Fabrication

If the input is misspelled, abbreviated non-standardly, or just unknown, the
skill MUST return either `status="ambiguous"` with a real candidates list or
`status="not_found"` with a "did you mean" list. It must never invent a
journal title or assign numbers to a guessed name.

## Public API

```python
from journal_if_lookup.query import lookup, _format_result

r = lookup("Nature")                # user input: any string
print(_format_result(r))
```

Or from CLI:

```bash
python "%USERPROFILE%/AppData/Roaming/LobsterAI/SKILLs/journal-if-lookup/query.py" "Lancet"
```

### `lookup(query, top=5)` return schema

| Field | Type | Meaning |
|------|------|---------|
| `status` | `ok` \| `ambiguous` \| `not_found` \| `error` | Resolution outcome |
| `matched_by` | `name` \| `abbreviation` \| `acronym` \| `acronym-fuzzy` \| `ISSN` \| `fuzzy` | How the match was found |
| `journal` | dict | Full record (only on `ok`) |
| `candidates` | list[dict] | Real candidate records (only on `ambiguous`) |
| `closest` | list[dict] | Closest real titles (only on `not_found`) |
| `message` | str | Human-readable explanation |

### The full journal record

The skill returns a dictionary with these fields (when available):

| Field | Source | Notes |
|------|--------|-------|
| `rank` | JCR | 1-indexed overall rank |
| `name` | `Journal name` | Official full name |
| `abbr` | `Abbreviated journal` | JCR abbreviation |
| `publisher` | `Publisher` | |
| `issn` | `ISSN` | |
| `eissn` | `eISSN` | |
| `categories` | `Categories` | "Multiple" if cross-listed |
| `editions` | `Editions` | SCIE / SSCI / AHCI etc. |
| `jcr_year` | `JCR year` | |
| `jif` | `2025 JIF` | **The number everyone asks for** |
| `jif_5y` | `5-year JIF` | |
| `jif_no_self` | `JIF without self cites` | |
| `jif_quartile` | `JIF quartile` | Q1 / Q2 / Q3 / Q4 |
| `jif_percentile` | `JIF percentile` | 0–100 |
| `jif_rank` | `JIF rank` | e.g. "1/333" |
| `jci` | `JCI` | Journal Citation Indicator |
| `jci_quartile` | `JCI quartile` | |
| `jci_percentile` | `JCI percentile` | |
| `jci_rank` | `JCI rank` | |
| `total_citations` | `Total citations` | |
| `total_articles` | `Total articles` | |
| `citable_items` | `Citable items` | |
| `pct_oa_gold` | `% OA gold` | |
| `immediacy_index` | `Immediacy index` | |
| `eigenfactor` | `Eigenfactor` | |
| `norm_eigenfactor` | `Normalized eigenfactor` | |
| `article_influence_score` | `Article influence score` | |
| `ais_quartile` | `AIS quartile` | |
| `ais_rank` | `AIS rank` | |
| `cited_half_life` | `Cited half-life` | years |
| `citing_half_life` | `Citing half-life` | years |
| `category_quartiles_json` | `Category quartiles JSON` | Full per-category breakdown — parse with `json.loads()` for cross-listed journals |

## How The Match Works

Layered, in order. Each layer is tried in turn; the first one that succeeds
returns immediately.

1. **ISSN fast path** — 7–9 digit string, looked up directly in the
   issn/eissn index. Strongest signal.
2. **Exact normalized name** — `norm(user_input) == norm(journal_name)`.
3. **Exact normalized abbreviation** — `norm(user_input) == norm(journal_abbr)`.
4. **Acronym index (full match)** — e.g. user types `JAMA` and the index has
   `JAMA` as a key. Multiple matches → ambiguous.
5. **Full score scan** — a scoring function walks all 22,643 records:
   - +1000 for ISSN exact
   - +950 for exact abbr
   - +900 for exact name
   - +850 for acronym match
   - +700 for abbr substring match
   - +600 for name substring match
   - +200-250 for token-set subset
   - +100-200 for typo-tolerant match (custom `_combined_ratio` blending
     `SequenceMatcher` and Jaccard char overlap — better than raw
     `difflib.get_close_matches` for short acronyms)
6. **Acronym fuzzy** (only for queries ≤ 6 chars that scored 0) — uses the
   custom ratio to find near-acronym keys. Returns `ambiguous` with the
   closest real abbreviation candidates.

If the top score < 200, the skill returns `not_found` with the highest-scoring
real titles. If the top-1 and top-2 scores are within 80 of each other, it
returns `ambiguous`.

## Files

```
journal-if-lookup/
├── SKILL.md            # this file
├── __init__.py         # re-exports lookup
├── query.py            # public API + CLI (uses __file__ for paths)
├── build_index.py      # rebuild the JSON index from data/2025IF.xlsx
└── data/
    ├── 2025IF.xlsx              # bundled JCR 2025 export
    └── journals_index.json      # pre-built, ~29 MB
```

The skill is fully self-contained — moving the entire `journal-if-lookup/`
folder anywhere on disk keeps it working, because both `query.py` and
`build_index.py` resolve paths relative to `__file__`. The original raw
Excel is bundled inside `data/` so the skill can be packaged and shipped
as one folder.

## Data Provenance

Built from `data/2025IF.xlsx` (JCR 2025 release, Clarivate). The xlsx
travels with the skill — no external file dependency.

### Rebuild the index

When Clarivate publishes a new JCR release, drop the new xlsx into
`data/2025IF.xlsx` and run:

```bash
python "<skill_folder>/build_index.py"
```

The script auto-locates the xlsx in any of these locations (first hit wins):

1. `<skill>/data/2025IF.xlsx`             (bundled, preferred)
2. `<skill>/2025IF.xlsx`                  (skill root fallback)
3. `<skill parent>/2025IF.xlsx`           (unpacked legacy layout)
4. `<skill grandparent>/2025IF.xlsx`      (LobsterAI/SKILLs/ root legacy)

It writes the rebuilt JSON to `<skill>/data/journals_index.json`.

## Behaviour On Ambiguous Input

The skill never silently guesses. If the user input matches multiple journals
with similar confidence, the response includes:

- a clear `status="ambiguous"` flag
- a `message` that names the issue and asks for confirmation
- a `candidates` list of the top 5 real records (so the user can pick)

If the user input has no good match at all, the response is:

- `status="not_found"`
- a `closest` list of the top 5 real titles ranked by string similarity
- a hint to try the full name, a different abbreviation, or an ISSN

## Behaviour On Typos

The skill distinguishes:

- **Single-character typos on short acronyms** (`JMAM` → JAMA family) —
  caught by acronym-fuzzy path, returns `ambiguous` with JAMA + siblings.
- **Missing/transposed characters in long names** (`Lanct` → LANCET) —
  caught by the token-set and substring matchers.
- **Multiple errors in long names** (`Nature Biotchnoogy` → NATURE
  BIOTECHNOLOGY) — caught by `_combined_ratio` substring tolerance, may
  return `not_found` with a "closest" list, which is the safer outcome.

In every case, the skill surfaces real records, never made-up ones.

## Versioning

- v1.0 (2026-06-17) — Initial release, 22,643 journals from JCR 2025
  release. 40/40 strict regression tests pass.


<!--
[LobsterAI 迁移元数据]
original_frontmatter: {"name": "journal-if-lookup", "description": "Look up academic journals in the local JCR 2025 index (22,643 records). Accepts full names, JCR abbreviations, ISSNs, or fragments. Returns the 2025 JIF, 5-year JIF, JIF quartile/rank, JCI, AIS, publisher, ISSN, citations, eigenfactor, and per-category quartiles. NEVER fabricates a journal — if the input is ambiguous, returns a candidates list and asks the user to confirm. If the input has no good match, returns the closest real titles for the user to pick from."}
-->
