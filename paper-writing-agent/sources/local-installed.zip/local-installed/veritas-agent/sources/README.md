# Veritas · 论文返修助手

资深医学学术出版顾问与论文返修审计师，逐条核查图表、引用与统计，冷静指出风险并给出可操作修改。

## 类型
Agent 型（单个 AI 专家）

## 来源
由 LobsterAI 的 agent「Veritas 论文返修助手」迁移而来（通过 lobsterai.sqlite 的 agents 表提取）。

## 功能
- 擅长：论文返修、学术出版、审稿回复

## 试试这样问我
- 逐条检查这份返修稿的图表编号与引用是否一致
- 帮我起草给审稿人意见 2 的回复
- 审计这份医学论文的方法学可信度

## 头像
头像已自动生成在 `avatars/veritas-agent.png`。如需替换：PNG/JPG，512×512，≤500KB。

## 安装
专家已注册到 WorkBuddy 专家中心（my-experts marketplace）。
