---
name: literature-workflow-orchestrator
description: 学术文献全流程 Skill 组合工作流
description_zh: 学术文献全流程 Skill 组合工作流
visibility: public
display_name: literature-workflow-orchestrator
display_name_en: literature-workflow-orchestrator
agent_created: true
disable: false
---

# 学术文献全流程 Skill 组合工作流

> 适用场景：医学/心内科/糖尿病大血管病变/STING/TREM2 等方向的系统性文献综述
> 严格度可调：宽松（宽召回）↔ 严格（窄精确）
> 工作目录：C:\Users\Lenovo\Desktop\AI工作路径

---

## 一、阶段化流程总览

```
┌─────────────────────────────────────────────────────────────────────────┐
│  Stage 0  检索式生成与策略设计                                           │
│     ↓                                                                  │
│  Stage 1  多源并行检索（PubMed + CrossRef + arXiv + bioRxiv + OpenAlex）│
│     ↓                                                                  │
│  Stage 2  元数据整合与去重                                               │
│     ↓                                                                  │
│  Stage 3  筛选与质量控制（IF/JCR/相关性/重复）                            │
│     ↓                                                                  │
│  Stage 4  翻译标题摘要（中→英或英→中）                                   │
│     ↓                                                                  │
│  Stage 5  全文 PDF 下载（按严格度分优先级）                                │
│     ↓                                                                  │
│  Stage 6  内容阅读、解析、总结                                            │
│     ↓                                                                  │
│  Stage 7  综述写作与导出                                                 │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 二、每个阶段可调用的 Skill 组合

### Stage 0：检索式生成与策略设计

**目标**：围绕一个研究主题，生成多组覆盖不同宽度的检索式。

**严格度三档**：


| 严格度        | 检索式特征                                                            | 示例（"STING 通路在糖尿病血管病变中的作用"）                                                                                                                                                         |
| ------------- | --------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 宽松 (loose)  | 关键词 OR、通配符 *、MeSH 上位词、跨物种                              | `("STING" OR "TMEM173") AND ("diabetes" OR "diabetic")`                                                                                                                                              |
| 中等 (medium) | 主题词 + 主题相关词、限定最近 5 年、review 包含                       | `("STING" OR "cGAS-STING") AND "diabetes" AND "vascular" Filters: 2020-2025, Review`                                                                                                                 |
| 严格 (strict) | 主题词 + 自由词组合、MeSH 加权、人类/英语、Original Article、Top 期刊 | `("STING"[Title/Abstract] OR "cGAS-STING"[Title/Abstract]) AND ("diabetic vasculopathy"[MeSH] OR "diabetic angiopathy"[Title/Abstract]) Filters: Humans, English, 2022-2025, Journal Article, IF≥5` |

**主用 Skill**：

- `citation-management` — 设计并验证检索式，支持 Google Scholar + PubMed 双源
- `literature-review` — 系统性综述整体设计
- `deep-research` — 多角度研究方法论
- `search-strategy` （位于 `nature-academic-search/references/`）— MeSH/标题词/摘要词组合

**辅助 Skill**：

- `hypogenic` / `hypothesis-generation` — 从假设出发生成验证型检索式
- `clinicaltrials-database` — 同步检索 ClinicalTrials.gov 避免漏掉未发表阴性结果

---

### Stage 1：多源并行检索

**目标**：跨数据库并行检索，互补覆盖。

**主用 Skill**（按数据库）：


| 数据源                   | 主 Skill                                 | 备用 Skill                                   | 备注                                                              |
| ------------------------ | ---------------------------------------- | -------------------------------------------- | ----------------------------------------------------------------- |
| PubMed（核心）           | `pubmed-database`                        | `pubmed-search`, `biopython`（Bio.Entrez）   | 必须用`pubmed-database`（直接 E-utilities REST API，可控 + 限流） |
| bioRxiv / medRxiv 预印本 | `literature_search_biorxiv`              | `biorxiv-database`                           | 预印本覆盖 6-12 个月领先                                          |
| arXiv                    | `literature_search_arxiv`                | `arxiv-database`                             | CS/Stats/Physics 跨界                                             |
| OpenAlex（开放综合）     | `literature_search_openalex`             | `openalex-database`, `openalx-bibliometrics` | 2.4 亿+ 条目，含反向 DOI 解析                                     |
| CrossRef（DOI 元数据）   | `web_fetch` → `api.crossref.org/works`  | （无专门 skill）                             | 元数据权威                                                        |
| Europe PMC               | `literature_search_europepmc`            | （无专门 skill）                             | 欧洲 + 预印本聚合                                                 |
| Semantic Scholar         | `web_fetch` → `api.semanticscholar.org` | `parallel-web`                               | 引文图、影响因子                                                  |
| 谷歌学术                 | `web_fetch` 备用 / `parallel-web`        | `multi-search-engine`                        | 不易直接抓取，作交叉验证                                          |
| Web of Science / Scopus  | `citation-management` 引导手工           | `parallel-web`                               | 需机构订阅                                                        |
| 中文文献 CNKI/万方       | `multi-search-engine`（CN 引擎部分覆盖） | 手工                                         | 提示用户在浏览器登录后导出                                        |

**严格度调节**：

- 宽松：5 个数据源全跑
- 中等：PubMed + OpenAlex + bioRxiv
- 严格：仅 PubMed（带严格过滤）

---

### Stage 2：元数据整合与去重

**目标**：合并多源结果，按 DOI/PMID 去重，补全缺失字段。

**主用 Skill**：

- `citation-management` — DOI/PMID 解析 + BibTeX 生成
- `nature-academic-search` 的 `scripts/format-converter.py` — PMID/DOI/arXiv → .nbib/.ris/.bib/.enw 统一格式
- `nature-academic-search` 的 `references/dedup-engine.md` — 跨源去重规则
- `nature-academic-search` 的 `references/citation-parser.md` — 从文本提取引文元数据

**辅助**：

- `python` + `pandas`（直接编程） — 适合 ≥100 条记录时

---

### Stage 3：筛选与质量控制

**目标**：按相关性 + 影响因子 + 时效性 + 期刊质量过滤。

**主用 Skill**：

- `topic-reference-literature` — 自动搜索 + IF/JCR 验证 + 必填 ≥20 篇 + 生成 Word 汇总表
  - 内置强制：JCR 年份/IF/分区缺失即报错
  - 输出：`01_Literature/00_Reference_Summary_Word/`
- `citation-management` — 批量解析 BibTeX、补充 IF/分区

**严格度调节**：


| 严格度 | 过滤条件                                     |
| ------ | -------------------------------------------- |
| 宽松   | 无 IF 过滤，仅按题目/摘要相关性              |
| 中等   | IF ≥ 3，5 年内，方法/样本量合理             |
| 严格   | IF ≥ 8，3 年内，Top 期刊 + RCT/前瞻队列优先 |

**辅助 Skill**：

- `jaspar-database`（如涉及转录因子 motif）
- `gtex-database` / `uniprot-database`（如涉及基因/蛋白功能）

---

### Stage 4：翻译标题摘要

**目标**：中↔英双向翻译，保留专业术语、缩写、基因/蛋白名。

**主用 Skill**（按需求）：


| 方向                 | Skill                           | 适用场景                                     |
| -------------------- | ------------------------------- | -------------------------------------------- |
| 英文论文 → 中文摘要 | `nature-reader`                 | **首选**：逐段中英对照，源锚定，图表位置保留 |
| 中文标题/摘要规范化  | `nature-polishing`              | Nature 风格英文润色                          |
| 整段翻译并保留格式   | `markitdown`                    | PDF → Markdown + 翻译（不擅长医学术语）     |
| 批量翻译 ≥50 条     | 自己用 LLM +`python` 循环调 API | 比 skill 更可控                              |

**重要细节**：

- 基因/蛋白名：保留英文（如 `STING`、`TREM2`），不翻译
- 缩写：首次出现给中文全称，后续保留英文
- 数字、单位、统计量：保留原格式
- 期刊名、机构名：保留原文

---

### Stage 5：全文 PDF 下载

**目标**：按可获得性优先级，依次尝试多个渠道。

**优先级链（严格→宽松）**：

```
1. PMC Open Access（PMC ID 已知时）       ← pubchem-database 检索 → 直链
2. Europe PMC（多数 NIH 资助可获取）        ← nature-academic-search scripts/preflight.py
3. DOI → 出版商页面（用户有机构订阅时）     ← browser 工具 + 用户机构 SSO
4. Univ 预印本服务器（bioRxiv、Research Square）
5. Unpaywall / OpenAlex（开放获取状态查询）  ← web_fetch
6. author 个人主页 / Google Scholar
7. Sci-Hub                   ← scansci-pdf MCP 工具（需配置）
8. 求助作者（最后手段）                    ← 邮件/ResearchGate
```

**主用 Skill**（按场景）：


| 场景                                 | Skill                                                              | 备注                          |
| ------------------------------------ | ------------------------------------------------------------------ | ----------------------------- |
| 单篇 DOI 下载（开放获取）            | `ref-downloader` 的 `run_ref_downloader.py` + 用户 Edge 浏览器登录 | 需要用户已登录机构 SSO        |
| 批量自定义下载（≥2 篇）             | `ref-downloader` 的 Mode B                                         | 同上                          |
| 13+ 数据源竞速下载（含 Sci-Hub/Tor） | `scansci-pdf` MCP 工具                                             | 需先`pip install scansci-pdf` |
| 仅开放获取                           | `pubmed-database` → PMC ID → `web_fetch` 直链                    | 100% 合规                     |
| 预印本（bioRxiv/medRxiv）            | `literature_search_biorxiv` 内置 download_paper.py                 | 完全开放                      |
| arXiv                                | `literature_search_arxiv` 内置 download_paper_source.py            | 完全开放                      |
| 用户提供 PDF                         | （直接走 Stage 6）                                                 |                               |

**严格度调节**：

- 严格：仅 PMC + 出版商官方；其他渠道一律不试
- 中等：PMC + 预印本 + 开放获取
- 宽松：PMC + 预印本 + 开放获取 + Unpaywall + 机构代理（如用户有）
- 极限：以上 + Sci-Hub（需用户明确授权）

**下载文件命名建议**：

```
{first_author}_{year}_{journal_short}_{title_slug}.pdf
例：Motwani_2019_NatCommun_cGAS-STING.pdf
```

---

### Stage 6：内容阅读、解析、总结

**目标**：从 PDF 提取结构化内容，生成可复用总结。

**主用 Skill**（按 PDF 来源）：


| 输入                     | Skill                 | 输出                                        |
| ------------------------ | --------------------- | ------------------------------------------- |
| PDF 路径                 | `pdf` （Claude 官方） | 文本/表格提取 + 表格填充                    |
| 复杂 PDF（扫描件、表单） | `pdf-processing-pro`  | 含 OCR + 验证                               |
| 论文 PDF                 | `nature-reader`       | 中英对照全文 + 源锚定`paper.md` + `assets/` |
| 论文 PDF                 | `markitdown`          | Markdown 化（结构较弱）                     |
| 多篇 PDF                 | `paper-2-web`         | 交互式 Web 总结（适合综述展示）             |

**结构化总结模板**（推荐存为 `paper_summary.md`）：

```markdown
# {Title}

## 基本信息
- 期刊: {journal} (IF={x}, Q={y})
- 年份: {year}
- DOI/PMID: {doi_or_pmid}
- 第一作者 / 通讯: {first} / {cor}
- 单位: {institution}

## 研究设计
- 类型: (RCT / 队列 / 病例对照 / 动物实验 / 综述 ...)
- 样本: (n=xxx, 物种/人群)
- 主要方法: ...

## 核心发现
1. ...
2. ...
3. ...

## 与本课题的关系
- 可借鉴: ...
- 可对照: ...
- 待核实: ...

## 关键图表
- Fig 1: ...
- Fig 2: ...
```

**辅助 Skill**：

- `data-extractor` — 从图中提取数值
- `pdf` — 表格抽取回 DataFrame

---

### Stage 7：综述写作与导出

**目标**：汇总所有论文，按结构输出综述文档。

**主用 Skill**（按输出格式）：


| 输出                           | Skill                        | 备注                         |
| ------------------------------ | ---------------------------- | ---------------------------- |
| **Word 综述表（必填 IF/JCR）** | `topic-reference-literature` | **首推**，强制质量门控       |
| Word 综述文                    | `docx` （Claude 官方）       | 完全可控                     |
| Word 综述文                    | `docx-official`              | 含批注/修订                  |
| Markdown 综述                  | （直接写文件）               | 灵活                         |
| LaTeX 综述                     | `latex-workflow`             | 投稿用                       |
| RMarkdown / Quarto             | `quarto-reporting`           | 可重复生成                   |
| PPT 汇报                       | `nature-paper2ppt`           | **首推** Nature 风格中文 PPT |
| PPT 通用                       | `pptx`                       | 完全可控                     |
| 海报                           | `latex-posters`              | 会议海报                     |

**综述结构建议**（心内科/糖尿病大血管病变方向示例）：

```
1. 背景
   1.1 糖尿病大血管病变的流行病学与临床负担
   1.2 现有治疗的局限
2. STING 通路概述
   2.1 cGAS-STING 的分子机制
   2.2 STING 在代谢性疾病中的研究进展
3. STING 与血管病变
   3.1 动脉粥样硬化
   3.2 血管钙化
   3.3 血管衰老
4. 治疗靶点与药物开发
   5. 未来研究方向与本课题切入点
6. 参考文献（≥20 篇，含 IF/JCR）
```

---

## 三、典型场景的 Skill 组合

### 场景 A：快速文献扫盲（5-15 分钟闪电模式）

```
Stage 0: citation-management
Stage 1: pubmed-database (限最新 5 年，IF≥5)
Stage 2: python + pandas 去重
Stage 3: 仅题目/摘要筛选
Stage 4: nature-reader 翻译摘要
Stage 6: markitdown 提取 PDF 全文
Stage 7: Markdown 综述
```

### 场景 B：系统综述投稿（30-60 分钟标准模式）

```
Stage 0: literature-review + citation-management
Stage 1: pubmed-database + OpenAlex + bioRxiv（3 源）
Stage 2: nature-academic-search format-converter.py
Stage 3: topic-reference-literature (强制 IF/JCR)
Stage 4: nature-polishing + nature-reader
Stage 5: ref-downloader (Mode A + 用户 SSO)
Stage 6: pdf (Claude 官方) + nature-reader
Stage 7: topic-reference-literature (生成 Word 汇总表)
        + latex-workflow (生成 LaTeX 投稿稿)
```

### 场景 C：深度单篇精读（30-60 分钟精修模式）

```
Stage 0: citation-management
Stage 1: pubmed-database 找到目标论文
Stage 5: ref-downloader (Mode A) 下载全文
Stage 6: nature-reader (生成中英对照 paper.md)
        + pdf (提取表格到 CSV)
        + data-extractor (从图中取数)
Stage 7: nature-response (撰写审稿意见)
        或 nature-writing (撰写综述段落)
```

### 场景 D：批量扫读相关领域（数小时至数天）

```
Stage 0: deep-research (多角度)
Stage 1: pubmed-database + literature_search_* (全 4 个) + OpenAlex
Stage 2: nature-academic-search 整套 (dedup + format-converter)
Stage 3: topic-reference-literature (≥20 篇 IF/JCR)
Stage 4: nature-reader 批量
Stage 5: ref-downloader (Mode B 批量下载)
Stage 6: 批量 nature-reader + paper_summary.md
Stage 7: literature-review 生成正式综述
```

---

## 四、跨 Skill 协同的注意事项

1. **输出格式互转**：

   - `nature-academic-search/scripts/format-converter.py` 是格式转换枢纽（.nbib/.ris/.bib/.enw）
   - `citation-management` 可生成 BibTeX
   - 多数下游 skill 接受 JSON manifest
2. **语言一致性**：

   - PubMed 用英文 MeSH
   - 中文文献用 `multi-search-engine` 找
   - 跨语言检索时先英后中，最后人工合并
3. **环境变量与凭证**（必读）：

   - NCBI: `NCBI_API_KEY`（[注册](https://www.ncbi.nlm.nih.gov/account/settings/)，3 → 10 req/s）
   - Semantic Scholar: `SEMANTIC_SCHOLAR_API_KEY`
   - CrossRef polite mailto: 在 `ref-downloader/config.local.toml` 中设
   - 这些环境变量在 `$env:USERPROFILE\.env` 或 skill 目录的 `.env`
4. **Windows 控制台 UTF-8 限制**：

   - 执行 `python <script>.py` 前先设 `$env:PYTHONIOENCODING = 'utf-8'`
   - 或用 `[Console]::OutputEncoding = [System.Text.Encoding]::UTF8`
5. **限流与礼貌池**：

   - PubMed 3 req/s，with API key 10 req/s
   - CrossRef 50 req/s，但加 `mailto=` 可进 polite pool
   - 大批量作业用 `science_skills_common` 的 `http_client.py` 自动限流
6. **失败兜底**：

   - PubMed 失败 → 用 `biopython` 的 `Bio.Entrez`
   - CrossRef 失败 → 用 `web_fetch` 直接调 API
   - PDF 下载失败 → 退到预印本 → 退到 Sci-Hub

---

## 五、可直接调用的脚本（无需配置）


| 脚本             | 路径                                                                                                                  | 功能                                                            |
| ---------------- | --------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------- |
| PubMed 全文 CLI  | `C:\Users\Lenovo\AppData\Roaming\LobsterAI\SKILLs\pubmed_database\scripts\pubmed_api.py`                              | `uv run scripts/pubmed_api.py out.json search_pubmed "query" 5` |
| 文献格式转换     | `C:\Users\Lenovo\AppData\Roaming\LobsterAI\SKILLs\nature-academic-search\scripts\format-converter.py`                 | `--pmid / --doi / --arxiv`                                      |
| 预连接性检查     | `C:\Users\Lenovo\AppData\Roaming\LobsterAI\SKILLs\nature-academic-search\scripts\preflight.py`                        | 验证 NCBI/CrossRef/arXiv API                                    |
| 参考文献全文下载 | `C:\Users\Lenovo\AppData\Roaming\LobsterAI\SKILLs\ref-downloader\scripts\run_ref_downloader.py`                       | `python run_ref_downloader.py <DOI>`                            |
| Word 参考文献表  | `C:\Users\Lenovo\AppData\Roaming\LobsterAI\SKILLs\topic-reference-literature\scripts\build_reference_summary_docx.py` | `python ... --manifest refs.json --output-name xxx.docx`        |

---

## 六、给 skill 作者的扩展建议

如果你希望未来进一步加强这套工作流，可以考虑安装以下 skill：


| 缺口                     | 推荐 skill                      | 用途                             |
| ------------------------ | ------------------------------- | -------------------------------- |
| 缺少 GWAS/PRS 全流程     | `gwas-database` / `ukb` 相关    | 临床数据关联分析                 |
| 缺少中文学术数据库直连   | 暂无原生（CNKI/万方需手工）     | 建议安装`gog` 通道后用浏览器辅助 |
| 缺少 PDF 全文翻译        | 可考虑加`markitdown` + LLM 翻译 | 中文长 PDF 处理                  |
| 缺少 Web of Science 直连 | `wos-api` 暂无，需机构订阅 API  | 引用报告                         |

---

## 七、调用决策树（Agent 实际执行时参考）

```
用户提出文献请求
    ↓
[问] 严格度？宽松/中等/严格
[问] 主题？中英文？
[问] 输出形式？扫盲/综述投稿/PPT/单篇精读
    ↓
Stage 0 → 选 citation-management / literature-review / topic-reference-literature
Stage 1 → 选 pubmed-database 必跑 + 按严格度加 literature_search_*
Stage 2 → nature-academic-search 格式转换（如果 ≥10 条）
Stage 3 → topic-reference-literature（如果要 IF/JCR 验证）
Stage 4 → nature-reader（中英对照）/ nature-polishing（英文润色）
Stage 5 → 按严格度选下载链（ref-downloader 主力）
Stage 6 → pdf / nature-reader / markitdown
Stage 7 → topic-reference-literature (Word) / latex-workflow (LaTeX) / nature-paper2ppt (PPT)
```

**严格度速查表**：


| 严格度 | 检索式                   | 数据源                  | 下载链              | 输出          |
| ------ | ------------------------ | ----------------------- | ------------------- | ------------- |
| 宽松   | 关键词 OR                | 全 5+ 源                | 含 Sci-Hub（授权）  | Markdown 笔记 |
| 中等   | MeSH+自由词、5 年        | PubMed+OpenAlex+bioRxiv | PMC+预印本+开放获取 | Word 综述     |
| 严格   | 主题词+过滤、3 年、IF≥5 | 仅 PubMed               | 仅 PMC+出版商       | LaTeX 投稿稿  |


<!--
[LobsterAI 迁移元数据]
original_frontmatter: {"name": "literature-workflow-orchestrator", "description": "学术文献全流程 Skill 组合工作流"}
-->
