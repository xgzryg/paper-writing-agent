﻿# wordpolish — 设计文档（v2）

## 1. 版本演进

- **v1** (2026-08-11 上午)：打包 6 个 sub-skill（4 原生 + 2 De-AI 子 + 1 新打包 ai-flavor-remover）；仅支持中文；链式上限硬性 2 个
- **v2** (2026-08-11 傍晚)：扩到 15 个 sub-skill；**新增英文去 AI 味能力**；链式规则放宽为"按场景需要"（默认 1 个，加强场景可达 4 个）

## 2. v2 升级动机

- Codex 已装 2098 个 skill，扫描后发现：
  - 真正用于"去 AI 味"的：unclecheng / writer / chinese-thesis-workbench / nature-polishing / content-rewriter / wechat-mp-suite / copywriting 等
  - **英文去 AI 味能力完全空白**——v1 没有英文 sub-skill
  - chinese-thesis-workbench 含 Python 脚本，是工程化 AIGC 治理工具
- 用户诉求："根据需要和场景等调用任意数量"——v1 链式上限 2 太死板

## 3. v2 sub-skill 池（15 个）

### A. 中文通用去 AI 味（3 个）
- A1 humanizer-zh（兜底默认）
- A2 unclecheng-reduce-ai-perception-v2__skillhub（8 类问题检测）
- A3 ai-flavor-remover（操作清单型，Codex 模式改造版）

### B. 中文场景化改写（4 个）
- B1 shuorenhua（小红书/公众号/工程师笔记）
- B2 content-rewriter（跨平台中文社交媒体）
- B3 wechat-mp-suite__skillhub（公众号端到端）
- B4 copywriting（营销文案）

### C. 学术（中/英）（4 个）
- C1 humanizer-zh-academic（中文学术降 AIGC）
- C2 chinese-thesis-workbench（中文论文 AIGC 工程化治理）
- C3 nature-polishing（Nature 期刊英文润色）
- C4 de-ai-writing（保真改写 + 反模板）

### D. 风格化（1 个）
- D1 good-writing（作家风格复现）

### E. 英文去 AI 味（2 个）— v2 新增
- E1 writer（英文修 AI 写作模式）
- E2 rupert-content-rewriter（英文跨平台）

### F. 辅助（1 个）
- F1 slides-polish（学术 slide 润色）

## 4. 链式规则（v2）

### 数量（不再硬性 2 个）

| 用户诉求 | 默认 | 上限 |
|---|---|---|
| 轻度改 | 1 | 1 |
| 中度改 | 1 | 2 |
| 加强/极致/最像人 | 2 | 4 |
| 场景矛盾 | 2 | 3 |
| agent 评估仍有 AI 味 | +1 | 累计 ≤ 4 |

### 方向（3 阶段）

1. **去味 / 保信息**：A1/A2/A3/B1/C1/E1
2. **调风格 / 场景化**：B1/B2/B4/C3/E2
3. **精修 / 保真**：A3/C4

### 禁止组合
- 任何 sub-skill → 自身
- D1 good-writing → 任何（不参与链式）

## 5. v1 → v2 改动清单

### 新增 sub-skill（9 个）
- A2 unclecheng-reduce-ai-perception-v2__skillhub
- B2 content-rewriter
- B3 wechat-mp-suite__skillhub
- B4 copywriting
- C2 chinese-thesis-workbench
- C3 nature-polishing
- E1 writer ← 填补英文空白
- E2 rupert-content-rewriter
- F1 slides-polish

### 文档更新
- `SKILL.md`：15 sub-skill 表格；description 含英文场景
- `agents/wordpolish.md`：15 sub-skill 接口；链式规则表
- `references/routing-table.md`：扩到 15 sub-skill 触发关键词
- `references/chain-rules.md`：放宽链式数量；3 阶段方向；新增英文链式组合
- `references/sub-skills-catalog.md`：新增（v1 没有）

## 6. 已知限制

- chinese-thesis-workbench 依赖 Python 脚本（`analyze_aigc_style.py`），需要 Codex 环境支持 Python
- wechat-mp-suite__skillhub 依赖 node/python3 / curl / jq
- nature-polishing 仅英文场景，中文论文英文润色可链 C1 → C3
- 英文 sub-skill (writer, rupert-content-rewriter) 实际效果未在 Codex 内验证（仅 GitHub 仓库介绍）

## 7. install

同 v1：把整个 `wordpolish/` 目录复制到 `D:\Codex\.codex\skills\wordpolish\`。

详见 `INSTALL.md`。
