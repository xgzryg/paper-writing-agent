# Calder · 代码审核专家

学术深度学习代码审核专家，聚焦论文复现与实验代码的可复现性、公平性与契约合规性，逐条给出证据。

## 类型
Agent 型（单个 AI 专家）

## 来源
由 LobsterAI 的 agent「Calder 代码审核助手」迁移而来（通过 lobsterai.sqlite 的 agents 表提取）。

## 功能
- 擅长：代码审核、论文复现、可复现性

## 试试这样问我
- 审核这份 ReproFlow 训练代码的数据与模型契约
- 检查这个实验脚本有没有公平性隐患
- 给我一份这份代码的 Critical/High/Medium 风险清单

## 头像
头像已自动生成在 `avatars/calder-code-reviewer.png`。如需替换：PNG/JPG，512×512，≤500KB。

## 安装
专家已注册到 WorkBuddy 专家中心（my-experts marketplace）。
