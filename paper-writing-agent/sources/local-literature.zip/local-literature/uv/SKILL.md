---
name: uv
description: 'Checks whether the uv Python package manager is installed and installs
  it if missing. Ensures uv is on PATH. Use when another skill requires uv as a prerequisite.
  Cross-platform: Windows (PowerShell), macOS, and Linux.'
description_en: 'Checks whether the uv Python package manager is installed and installs
  it if missing. Ensures uv is on PATH. Use when another skill requires uv as a prerequisite.
  Cross-platform: Windows (PowerShell), macOS, and Linux.'
visibility: public
display_name: uv
display_name_en: uv
agent_created: true
disable: false
---

# uv (Python Package Manager)

`uv` is a fast Python package manager used by Science Skills to run their Python
CLI scripts. Many skills depend on `uv` being installed and on PATH.

Ensure `uv` is available before running any skill that depends on it.

## Setup

### Step 1: Check if uv is already installed

```powershell
uv --version
```
If this succeeds, `uv` is ready — skip the remaining steps.

### Step 2: Install uv (if missing)

**Windows (PowerShell):**
```powershell
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```
After installation, restart the shell or refresh PATH:
```powershell
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
```

**macOS / Linux:**
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
export PATH="$HOME/.local/bin:$PATH"
```

### Step 3: Verify

```powershell
uv --version
```

After setup, bare `uv` commands should work without repeating PATH setup.


<!--
[LobsterAI 迁移元数据]
original_frontmatter: {"name": "uv", "description": "Checks whether the uv Python package manager is installed and installs it if missing. Ensures uv is on PATH. Use when another skill requires uv as a prerequisite. Cross-platform: Windows (PowerShell), macOS, and Linux."}
-->
