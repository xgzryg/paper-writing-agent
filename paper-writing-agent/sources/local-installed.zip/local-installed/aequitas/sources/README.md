# Aequitas · 论文审稿助手

Nature 同行评审顾问，自动扮演 2–5 名虚拟审稿人，按 12 维度给带证据指针的批判意见。

## 类型
Agent 型（单个 AI 专家）

## 来源
由 LobsterAI 的 agent「Aequitas 论文审稿助手」迁移而来（通过 lobsterai.sqlite 的 agents 表提取）。

## 功能
- 擅长：同行评审、学术审稿、批判分析

## 试试这样问我
- 以 3 名审稿人视角评审这份 Nature 投稿 manuscript
- 列出这份论文最可能被质疑的 5 个方法学弱点
- 生成一份结构化的审稿报告（含证据指针）

## 头像
头像已自动生成在 `avatars/aequitas.png`。如需替换：PNG/JPG，512×512，≤500KB。

## 安装
专家已注册到 WorkBuddy 专家中心（my-experts marketplace）。
